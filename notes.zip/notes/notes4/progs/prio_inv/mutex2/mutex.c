/* mutex.c - implement mutex with priority inheritence */

#include <conf.h>
#include <kernel.h>
#include <mem.h>
#include <sem.h>
#include <q.h>
#include <proc.h>
#include "mutex.h"

SYSCALL mutex_lock(MUTEX_REC_PTR *mutex_var)
{
 int nsem, newprio, owner_pid;
 int ps, ans;

 disable(ps);

  if ((*mutex_var) == (MUTEX_REC_PTR)NULL) // mutex has no owner
  {
    nsem = screate(1);
    if (nsem == SYSERR)
    {
      restore(ps);
      return SYSERR;
    } /* if */
    (*mutex_var) = (MUTEX_REC_PTR)getmem(sizeof(MUTEX_REC));
    (*mutex_var)->nsem = nsem;
    (*mutex_var)->owner_original_priority = proctab[currpid].pprio;
    (*mutex_var)->mutex_priority = proctab[currpid].pprio;

  } /* if */
  else // mutex has owner
    if ((newprio = proctab[currpid].pprio) > (*mutex_var)->mutex_priority)
    {
       (*mutex_var)->mutex_priority = newprio;
       owner_pid = (*mutex_var)->owner_pid;
       if (proctab[owner_pid].pstate == PRREADY)
       {
         dequeue(owner_pid);
         insert(owner_pid, rdyhead, newprio);
       }// if
       proctab[owner_pid].pprio = newprio;
    } //if 
  ans = wait((*mutex_var)->nsem); // includes resched fore else if
  (*mutex_var)->owner_pid = currpid;
  (*mutex_var)->owner_original_priority = proctab[currpid].pprio; 
  proctab[currpid].pprio =  (*mutex_var)->mutex_priority;
  restore(ps);
  return  ans;

} /* mutex_lock */

SYSCALL mutex_unlock(MUTEX_REC_PTR *mutex_var)
{
 int ps, next, newprio;

  disable(ps);
  if ( ((*mutex_var) == (MUTEX_REC_PTR)NULL) ||
     ((*mutex_var)->owner_pid != currpid) )
  {
   restore(ps); 
   return SYSERR;
  } // if

   // I own the mutex
    if ( isempty(semaph[(*mutex_var)->nsem].sqhead))
      {
       restore(ps);
       return OK;
      } /* if */


    next = semaph[(*mutex_var)->nsem].sqhead;
    next = q[next].qnext;
    newprio = proctab[next].pprio;
    while ( (next = q[next].qnext) < NPROC)
    {
      int tempprio;
      if ((tempprio = proctab[next].pprio) > newprio)
        newprio =  tempprio;
    }// while
    (*mutex_var)->mutex_priority = newprio;
    proctab[currpid].pprio = (*mutex_var)->owner_original_priority;
    signal((*mutex_var)->nsem);
    restore(ps);
    return OK; 

} /* mutex_unlock */

SYSCALL mutex_relock(MUTEX_REC_PTR *mutex_var)
{
 int ps, next, newprio, nsem, newpid;

  disable(ps);
  if ( ((*mutex_var) == (MUTEX_REC_PTR)NULL) ||
     ((*mutex_var)->owner_pid != currpid) )
  {
   restore(ps); 
   return SYSERR;
  } // if
    nsem = (*mutex_var)->nsem;

    if ( isempty(semaph[nsem].sqhead))
      {
       sdelete(nsem);
       freemem((*mutex_var), sizeof(MUTEX_REC));
       (*mutex_var) = MUTEX_VAR_INITIALIZER;
       restore(ps);
       return OK;
      } /* if */


    next = semaph[nsem].sqhead;
    newpid = q[next].qnext;
    newprio = proctab[currpid].pprio;
    while ( (next = q[next].qnext) < NPROC)
    {
      int tempprio;
      if ((tempprio = proctab[next].pprio) > newprio)
        newprio =  tempprio;
    }// while
    (*mutex_var)->mutex_priority = newprio;
    proctab[currpid].pprio = (*mutex_var)->owner_original_priority;
    enqueue(currpid, semaph[nsem].sqtail);
    semaph[nsem].semcnt--;
    proctab[currpid].pstate = PRWAIT;
   
    (*mutex_var)->owner_pid = newpid;
    (*mutex_var)->owner_original_priority = proctab[newpid].pprio; 
    proctab[newpid].pprio =  (*mutex_var)->mutex_priority;

    signal(nsem);
    restore(ps);
    return OK; 

} /* mutex_relock */

