/* mex1.c - xmain, prod2, cons2 */

#include <conf.h>
#include <kernel.h>
#include "mutex.h"

int	n=0;		/* external variables are shared by all processes */



/*------------------------------------------------------------------------
 *  xmain  --  producer and consumer processes synchronized with semaphores
 *------------------------------------------------------------------------
 */
xmain()
{
	int	prod2(), cons2();
        int i;
        static MUTEX_VAR mutex1 = MUTEX_VAR_INITIALIZER;

        mutex_lock(&mutex1);
        resume(create(cons2,INITSTK,INITPRIO-1,"cons",1,&mutex1));
        sleep(1);
        resume(create(prod2,INITSTK,INITPRIO-3,"prod",1,&mutex1));
        sleep(1);
        mutex_unlock(&mutex1);

} // xmain

/*------------------------------------------------------------------------
 *  prod2  --  increment n 2000 times, waiting for it to be consumed
 *------------------------------------------------------------------------
 */
prod2(mutex1_ptr)
MUTEX_VAR *mutex1_ptr;
{
	int	i;

        mutex_lock(mutex1_ptr);

        for (i=1; i<=9; i++) {
		n++;
                mutex_relock(mutex1_ptr);
        } // for
}

/*------------------------------------------------------------------------
 *  cons2  --  print n 2000 times, waiting for it to be mutex1
 *------------------------------------------------------------------------
 */
cons2(mutex1_ptr)
MUTEX_VAR *mutex1_ptr;
{
	int	i;

        mutex_lock(mutex1_ptr);
        for (i=1; i<=9; i++) {
                printf("n is %d\n",n);
                mutex_relock(mutex1_ptr);
	}
}
