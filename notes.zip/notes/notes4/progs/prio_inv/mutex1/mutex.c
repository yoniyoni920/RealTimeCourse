/* mutex.c */

#include <conf.h>
#include <kernel.h>
#include <mem.h>
#include <sem.h>
#include <q.h>
#include <proc.h>
#include "mutex.h"

int arr[30];
int op[30];
int top = 0;


SYSCALL mutex_lock(MUTEX_REC_PTR *mutex_var)
{
 int nsem;
 int ps, ans;

 disable(ps);
 arr[top] = currpid;
 op[top] = 1;
 top++;
 ans = 0;

  if ((*mutex_var) == (MUTEX_REC_PTR)NULL)
  {
    nsem = screate(0);
    if (nsem == SYSERR)
    {
      restore(ps);
      return SYSERR;
    } /* if */
    (*mutex_var) = (MUTEX_REC_PTR)getmem(sizeof(MUTEX_REC));
    (*mutex_var)->nsem = nsem;
    (*mutex_var)->owner_pid = currpid;

  } /* if */
  else
    ans = wait((*mutex_var)->nsem);

    restore(ps);
    return  ans;

} /* mutex_lock */

SYSCALL mutex_unlock(MUTEX_REC_PTR *mutex_var)
{
 int ps;

  disable(ps);
 arr[top] = currpid;
 op[top] = 2;
 top++;
  

  if ( ((*mutex_var) == (MUTEX_REC_PTR)NULL) ||
     ((*mutex_var)->owner_pid != currpid) )
  {
   restore(ps);
   return SYSERR;
  }

    if ( isempty(semaph[(*mutex_var)->nsem].sqhead))
      {
       sdelete((*mutex_var)->nsem);
       freemem((*mutex_var), sizeof(MUTEX_REC));
       (*mutex_var) = MUTEX_VAR_INITIALIZER;
       restore(ps);
       return OK;
      } /* if */
    else
    {
      int nsem, sqhead;
      nsem = (*mutex_var)->nsem;
      sqhead = semaph[nsem].sqhead;
      (*mutex_var)->owner_pid = firstid(sqhead);
      signal(nsem);
    }// else

  restore(ps);
  return OK; 

} /* mutex_unlock */

// relock = unlock + lock
SYSCALL mutex_relock(MUTEX_REC_PTR *mutex_var)
{
 int ps;

  disable(ps);
 arr[top] = currpid;
 op[top] = 2;
 top++;
  

  if ( ((*mutex_var) == (MUTEX_REC_PTR)NULL) ||
     ((*mutex_var)->owner_pid != currpid) )
  {
   restore(ps);
   return SYSERR;
  }

   // I am owner of the mutex
    if ( isempty(semaph[(*mutex_var)->nsem].sqhead))
      {
       restore(ps);
       return OK;
      } /* if */
    else
    {
      int nsem, sqhead;
      nsem = (*mutex_var)->nsem;
      sqhead = semaph[nsem].sqhead;

      (*mutex_var)->owner_pid = firstid(sqhead);
      enqueue(currpid, semaph[nsem].sqtail);
      semaph[nsem].semcnt--;
      proctab[currpid].pstate = PRWAIT;

      signal(nsem);
    }// else

  restore(ps);
  return OK; 

} /* mutex_relock */

