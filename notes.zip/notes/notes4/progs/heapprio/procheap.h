/* procheap.h  */


typedef struct heap_rec
{
 int pid;
 int key;
 unsigned long count;

} HEAP_REC, HEAP_REC_PTR;

extern int heaptop;

extern HEAP_REC heaptab[];
extern int where_in_heap[];



extern void insert_heap(int pid, int key,
               unsigned long int count);

extern int heap_maxkey();


extern int get_heap_max();

extern void remove_from_heap(int pid);

extern unsigned  long int ready_count;

