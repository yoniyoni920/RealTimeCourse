/* procheap.c  */

#include <kernel.h>
#include <proc.h>
#include "procheap.h"


int heaptop = 0;
unsigned long int ready_count=0;

HEAP_REC heaptab[NPROC+1];
int where_in_heap[NPROC];


int is_greater(HEAP_REC *px, HEAP_REC *py)
{
  if(px->key > py->key)
    return 1;
  else
  if((px->key == py->key) && (px->count < py->count))
    return 1;
  else
    return 0;


} //is_greater


void swap(HEAP_REC *px, HEAP_REC *py)
{
  HEAP_REC temp;

    temp = *px;
    *px = *py;
    *py = temp;

}  /* swap */


void shift_up(int pos)
{
  int r, r2;

    r = pos;
    r2 = r/2;
    while(r2 > 0)
    {
     if (is_greater(&heaptab[r], &heaptab[r2]))
     {
       where_in_heap[heaptab[r2].pid] = r;
       where_in_heap[heaptab[r].pid] = r2;
       swap(&heaptab[r], &heaptab[r2]);
     }
     else break;
     r = r2;
     r2 = r/2;
    } /* while */
} /* shift_up */


void shift_down(int pos)
{

  int r, r2;

  r = pos;
  while(r <= heaptop/2)
  {
   r2 = 2*r;
   if ( r2 == heaptop)
   {
    /* r has one child at 2*r */
    if ( is_greater(&heaptab[r], &heaptab[r2]) )
            /* heaptab[r] is not the maximum */
    {
      swap(&heaptab[r], &heaptab[r2]);
      where_in_heap[heaptab[r].pid] = r;
      where_in_heap[heaptab[r2].pid] = r2;
    } // if
    break;
   } /* if */
   else /* r has two children,  at 2*r and 2*r+1  */
    {
      /* heaptab[r] is not min of subtree */
      if ( is_greater(&heaptab[r2], &heaptab[r])
           && is_greater(&heaptab[r2], &heaptab[r2+1]))
      /* heaptab[2*r] is the larger of the sons */
      {
        swap(&heaptab[r], &heaptab[r2]);
        where_in_heap[heaptab[r].pid] = r;
        where_in_heap[heaptab[r2].pid] = r2;
        r = r2;
      }
      else
       if ( is_greater(&heaptab[r2+1], &heaptab[r])
       /* heaptab[r] is not max of subtree */
            && heaptab[r2].key < heaptab[r2+1].key )
            /* heaptab[2*r+1] is the larger of the sons */
       {
         swap(&heaptab[r], &heaptab[r2+1]);
         where_in_heap[heaptab[r].pid] = r;
         where_in_heap[heaptab[r2+1].pid] = r2+1;
         r = r2 + 1;
       }// if
       else
         break;
    } /* else */
  } /* while */

} /*shift_down */



void insert_heap(int pid, int key, unsigned long int count)
{
  heaptop++;
  heaptab[heaptop].pid = pid; 
  heaptab[heaptop].key = key;
  heaptab[heaptop].count = count;
  where_in_heap[pid] = heaptop;
  shift_up(heaptop);
} // insert_heap

int heap_maxkey()
{
 return heaptab[1].key;

} // heap_maxid


int get_heap_max()
{
  int maxpid;

  maxpid = heaptab[1].pid;
  heaptab[1] = heaptab[heaptop];
  where_in_heap[heaptab[1].pid] = 1;

  shift_down(1);
  heaptop--;
  return maxpid;

} //get_heap_max

void remove_from_heap(int pid)
{
  int pos;

  pos =  where_in_heap[pid];
  heaptab[pos] = heaptab[heaptop];
  where_in_heap[heaptab[pos].pid] = pos;

  shift_up(pos);
  shift_down(pos);
  heaptop--;

} //get_heap_max


