/* segf1.c - Demonstrate segmentation fault */
/* Under UNIX, we are no longer free to read / write wherever we please */

#include <stdio.h>


void main()
{
  int i, *iptr;

  iptr = &i;

  *iptr = 99;

  printf("\ni = %d, iptr = %p, *iptr = %d\n\n", i, iptr, *iptr);
  

  iptr = (int *) 256; /* Assign arbitrary value to pointer */

      /* if we can print this, then assignment was OK */
  printf("Pointer Assignment OK: iptr = %p\n\n", iptr);
    
  
  i = *iptr; /* Read from arbitrary pointer */

      /* if we can print this, then read was OK */
  printf("Pointer read OK: iptr = %p, i = %d\n\n", iptr, i);

  *iptr = 99;

      /* if we can print this, then write was OK */
  printf("Pointer Write OK:  i = %d, iptr = %p, *iptr = %d\n\n", 
       i, iptr, *iptr);


}
