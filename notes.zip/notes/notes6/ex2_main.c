#include <stdio.h> 

int main(int argc, char *argv[]){

  int fd, c = 0;

//  fp = fopen(argv[1], "wt");

  fd = my_fopen_w(argv[1]);
  
  printf("Enter text, indicate EOF by Enter\n");

//  while( (c = getchar()) != EOF)
//     fputc(c, fp);
 
  while (c != 10)
  {
     c = my_getchar();
     my_fputc(c,fd);  
  } // while

//  fclose(fp);

  my_fclose(fd);

  return 0;

} // main
