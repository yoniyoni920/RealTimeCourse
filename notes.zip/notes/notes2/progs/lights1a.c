
// lights1a.c

#include <dos.h>
#include <stdio.h>

#define SCROLL 1
#define NUMS 2
#define CAPS 4




char LIGHTS[] = {NUMS, CAPS, SCROLL, CAPS, NUMS, CAPS+SCROLL, NUMS+CAPS, 
                             NUMS+SCROLL,  NUMS+SCROLL+CAPS, 0};

int main()
{

  char al;
  int  i;
  long int j;

i = 0;

do {

     outportb(0x60, 0xED);
         

      al = LIGHTS[i];

     outport(0x60, al);


     sleep(5);    

       i++;


   } while( i < 12);

return 0;

} // main



