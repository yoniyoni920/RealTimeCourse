
//    clk3.c

#include <stdio.h>
#include <dos.h>

void interrupt TIMER(void);
int COUNT100 = 100;
char TENHOUR;
char HOURS;
char TENMIN;
char MINUTES; 
char TENSEC;
char SECONDS;
char OLDMASK;
void interrupt (*origint8isr)(void); // pointer to function
union REGS regs;
struct REGPACK regpack;

int main(int argc, char *argv[])
{
  char  value;
  int flag;

   printf("argv[1] = %s\n", argv[1]);

   TENHOUR = argv[1][0];
    HOURS = argv[1][1];
    TENMIN = argv[1][3];
     MINUTES = argv[1][4];
     TENSEC = argv[1][6];
      SECONDS = argv[1][7];


   origint8isr = getvect(8);
   setvect(8, TIMER);



//TIMER COMMAND: SELECT CHANNEL 0;
//                   ;                READ / WRITE LSB
//                   ;                MODE 3: BINARY
// 0x36 =  0000 0000 0011 0000

   outportb( 0x43, 0x36);

//       11932  ; DESIRED COUNT VALUE FOR 100HZ RESULT

//    TRANSFER THE LSB 

value = (11932 & 0xFF);

outportb( 0x40, value);

//    TRANSFER THE MSB 

value = (11932 / 256);
outportb( 0x40, value);


flag = 1;
while(flag == 1)
{
  char temp;

    putchar(TENHOUR);
    putchar(HOURS);
    putchar(':');
    putchar(TENMIN);
    putchar(MINUTES);
    putchar(':');
    putchar(TENSEC);
    putchar(SECONDS);
    putchar(13);

    temp =  SECONDS;
     // Wait for seconds to change
    while (temp == SECONDS)
          ;

  regpack.r_ax = 256; 
  intr(0x16, &regpack);
  if ( (regpack.r_flags & 64) == 0)
   {
     // Read key
      regs.h.ah = 0;
      int86(0x16, &regs, &regs);
      flag = 0;
   } // if

 

} // while(1)  

// RESTORE INT8 FREQUENCY

   outportb( 0x43, 0x36);
   outportb( 0x40, 0);
   outportb( 0x40, 0);


   setvect(8, origint8isr);

return 0;

} // main

  
void interrupt TIMER(void)
{
  int incflag=0;

      incflag = 0;
      COUNT100--;
      if (COUNT100 <= 0)
       {
           COUNT100 = 100;
            incflag = 1;
       } // if 

  if (incflag == 0)
     goto noinc;

   if ( (SECONDS == '9') && (TENSEC == '5' ) && (MINUTES == '9') && (TENMIN == '5') &&
      (HOURS == '3') && (TENHOUR == '2') )
   {
     SECONDS = TENSEC = MINUTES = TENMIN = HOURS = TENHOUR = '0';
     goto noinc;     
   } // if


       if (SECONDS == '9')
              {
                SECONDS = '0';
              }
              else
              {
                SECONDS++;
		goto noinc;
              } // else

         if  (TENSEC == '5' )
                 {
                    TENSEC = '0';
                 }
          else
              {
                TENSEC++;
		goto noinc;
              } // else

          if (MINUTES == '9')
             {
                 MINUTES = '0';
             }
          else
              {
                MINUTES++;
		goto noinc;
              } // else
            


       if (TENMIN == '5')
            {
               TENMIN = '0';
            } // if 
          else
              {
                incflag = 0;
                TENMIN++;
		goto noinc;
              } // else

       if (HOURS == '9')
            {
               HOURS = '0';
            } // if 
          else
              {
                HOURS++;
		goto noinc;
              } // else

       if (TENHOUR == '2')
            {
               TENHOUR = '0';
            } // if 
          else
              {
                TENHOUR++;
              } // else

noinc:

       outportb( 0x20, 0x20 );
 
} // TIMER


