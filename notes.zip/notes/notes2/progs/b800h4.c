// b800h3.C

#include <stdio.h>
#include <dos.h>
#include <conio.h>


// This program demonstrates the use of hardware scrolling.

int count = 0;
int base = 0;
int direction = 0;

  int  far *b800h;
  int value, i, ax;





int main()
{
  union REGS regs;
  struct REGPACK regpack;

  regs.h.ah = 0;
  regs.h.al = 1;
  int86(0x10, &regs, &regs);
   

   b800h = NULL;


  ((unsigned long int)b800h) = 0xB800 * 65536; 

   value = 'A' + 256*3;


for(i=0; i < 2000; i++)
  {
    *b800h = value;
      b800h++;
  } // for



   value = 'B' + 256*5;



for(i=0; i < 2000; i++)
  {
    *b800h = value;
      b800h++;
  } // for



   value = 'C' + 256*6;



for(i=0; i < 2000; i++)
  {
    *b800h = value;
      b800h++;
  } // for


   value = 'D' + 256*7;



for(i=0; i < 2000; i++)
  {
    *b800h = value;
      b800h++;
  } // for


//  ; 3D4H  Graphics adapter address register port
//  ; 3D5H  Graphics adapter data register port

//;
//; Set the cursor address registers
//;

ax = 14 +  ((40*48+20) & (0xFF00));

outport(0x3D4, ax);



ax = 15 +  ((40*48+20) & (0xFF))*256  ;

outport(0x3D4, ax);


ax = 10;
outport(0x3D4, ax);

ax = 11 + 15*256;
outport(0x3D4, ax);


//;
//;PART 2 : Scroll the display every second until a key is hit
//;

while(1)
{

delay(100);

//;
//asm {
//  MOV              AH,1         // User pressed key?
//  INT              16H
//  JZ               Scroll       // No, scroll
//  MOV              AH,0         // Yes, read the key
//  INT              16H
//  CMP              AH,1         // Is it Esc?
//  JNE               Skip1     // Yes - return to DOS
//}

regpack.r_ax = 256;
intr(0x16, &regpack);
if ( (regpack.r_flags & 64) == 0)
  {
    regs.h.ah = 1;
    int86(0x16, &regs, &regs);
    if (regs.h.ah == 1)
        break;
    // Read the key
    regs.h.ah = 0;
    int86(0x16, &regs, &regs);
    if (regs.h.ah == 1)
        break;
 
 // Wait for another key
    regs.h.ah = 0;
    int86(0x16, &regs, &regs);
    if (regs.h.ah == 1)
        break;

  } // if
    

//goto ToReturn;

//Skip1:





//asm {
//  MOV              AH,0         // No: Wait for another key
//  INT              16H
//  CMP              AH,1         // Was it Esc?
//  JNE               Skip2     // Yes - return to DOS
//}
//                               ; No - Continue




//goto ToReturn;

//Skip2:

Scroll:

if (direction == 0)
  {
    count++;
    if (count >= 160)
       direction = 1;
    else 
      base = base + 40;
  } // if
else
//Backwards:
  {
    count--;
    if (count <= 0)
    {
      direction = 0;
    } // if
    else
      base = base - 40;

   } // else


//Update:

ax = 12 +  (base & (0xFF00));

outport(0x3D4, ax);

ax = 13 +  (base & (0xFF))*256  ;

outport(0x3D4, ax);

}// while(1)

//;
//ToReturn:

  regs.x.ax = 3;
  int86(0x10, &regs, &regs);

  
 return 0;

} // main

