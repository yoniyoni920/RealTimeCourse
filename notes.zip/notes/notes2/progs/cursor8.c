//;
//; cursor8.c
//;
//;This program demonstrates cursor manipulation.
//;
//;

#include <stdio.h>
#include <dos.h>
//#include <conio.h>





int CursorPos;
int Base;
int Cursor_Sizes[]  = {0x0407,0x0205,0x0306,0x000F,0x010F,0x020F,0x030F,0x040F,
                         0x050F,0x060F,0x070F,0x080F,0x090F,0x0A0F,0x0B0F,0x0C0F,
                         0x0D0F,0x0E0F,0x000E,0x010E,0x020E,0x030E,0x040E,0x050E,
                         0x060E,0x070E,0x080E,0x090E,0x0A0E,0x0B0E,0x0C0E,0x0D0E,
                         0x0C0D,0x0B0D,0x0A0D,0x090D,0x080D,0x070D,0x060D,0x050D,
                         0x040D,0x030D,0x020D,0x010D,0x010C,0x020C,0x030C,0x040C,
                         0x050C,0x060C,0x070C,0x080C,0x090C,0x090C,0x0A0C,0x0B0C,
                         0x0A0B,0x090B,0x080B,0x070B,0x060B,0x050B,0x040B,0x030B,
                         0x020B,0x010B,0x010A,0x020A,0x030A,0x040A,0x050A,0x060A,
                         0x070A,0x080A,0x090A,0x0809,0x0709,0x0609,0x0509,0x0409,
                         0x0309,0x0209,0x0109,0x0108,0x0208,0x0308,0x0408,0x0508,
                         0x0708,0x0607,0x0507,0x0407,0x0307,0x0207,0x0107,0x0106,
                         0x0608,0x0206,0x0306,0x0406,0x0506,0x0405,0x0305,0x0205,
                         0x0104,0x0204,0x0304,0x0203,0x0103,0x0203,0x0102,0x0002,
                         0x0105,0x0001 };


void SetCursorPos(int pos)
{
 int ax;

ax = 14 +  ((pos) & (0xFF00));

outport(0x3D4, ax);



ax = 15 +  (pos & (0xFF))*256  ;

outport(0x3D4, ax);


} // SetCursorPos



void SetCurSize(int currsize)
{
 int ax;


ax = 10  + (currsize & 0xFF00);
outport(0x3D4, ax);

ax = 11  + (currsize & 0xFF)*256 ;
outport(0x3D4, ax);


} // SetCurSize

int main()
{

  int  far *b800h;
  int value, i, ax, flag, si, ch1;
  union REGS regs;

//;PART1 : INITIALIZE THE DISPLAY ADAPTER
//;

// Set window to 25x40 

  regs.h.ah = 0;
  regs.h.al = 1;
  int86(0x10, &regs, &regs);
 



//  0B800H     ; SEGMENT ADDRESS OF MEMORY ON COLOR ADAPTER
//;
//  SET UP EXTRA SEGMENT REGISTER
//  ' ' CHARACTER SPACE TO FILL ADAPTER MEMORY
//   ATTRIBUTE BYTE : INTENSE YELLOW
//;
//; WRITE 'A' IN MID SCREEN
//;
//  MOV              BYTE PTR ES:[2*(12*40+20)],'A'
//;

 ((unsigned long int)b800h) = 0xB800 * 65536; 

   value = ' ' + 256*14;  // space + ATTRIBUTE BYTE : INTENSE YELLOW BLACK BACKGROUND


for(i=0; i < 1000; i++)
  {
    b800h[i] = value;
  } // for

b800h[12*40+20] = b800h[12*40+20]  + 'A' - ' '; 

//; SET THE CURSOR ADDRESS REGISTERS

SetCursorPos(12*40+20);



si = 0;

while(1)
{
   ax = Cursor_Sizes[si];
   SetCurSize(ax);
   si++;
   if (si >= 114)
    si = 0;
 
// Wait for key strike

  regs.h.ah = 0;
  int86(0x16, &regs, &regs);
  if (regs.h.ah == 1)
      break;

} // while(1)

// Return:

// Reset window to 25x80 

  regs.h.ah = 0;
  regs.h.al = 2;
  int86(0x10, &regs, &regs);
 

} // main