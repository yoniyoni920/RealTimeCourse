#include <stdio.h>
#include <conio.h>
#include <dos.h>

#define ON (1)
#define OFF (0)


 void ChangeSpeaker( int status )
 {
  int portval;

      portval = 0;

   portval = inportb( 0x61 );

    if ( status==ON )
     portval |= 0x03;
      else
       portval &=~ 0x03;
    
   outportb( 0x61, portval );
  

  } /*--ChangeSpeaker( )----------*/

void mysound( int hertz )
{
	 unsigned divisor = 1193180L / hertz;

	  ChangeSpeaker( ON );
         outportb( 0x43, 0x96 );
         outportb( 0x42, divisor & 0xFF ) ;
         outportb( 0x43, 0xA6 ) ;
       outportb( 0x42, divisor >> 8 ) ;

   } /*--Sound( )-----*/

   void mynosound( void )
        {
             ChangeSpeaker( OFF );
        } /*--NoSound( )------*/



void playTone(int frequency, int duration) {
    mysound(frequency);
    delay(duration);
    mynosound();
    delay(100); // Short delay between notes
}

void playYonatanHakatan() {
    int notes[] = {
        392, 330, 330, 349, 294, 294, 261, 294, 330, 349, 392, 392, 392 // G E E F D D C D E F G G G
    };

    int durations[] = {
        500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500 // G E E F D D C D E F G G G
    };
    int i;
    int length = sizeof(notes) / sizeof(notes[0]);
    for (i = 0; i < length; i++) {
        playTone(notes[i], durations[i]);
    }
}

int main() {
    printf("Playing YonatanHakatan (intro)...\n");
    playYonatanHakatan();
    printf("Done.\n");
    return 0;
}