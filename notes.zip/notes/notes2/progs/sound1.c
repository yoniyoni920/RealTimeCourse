// sound1.c
#include <dos.h>
#include <stdio.h>

#define ON (1)
#define OFF (0)

volatile int count;

void interrupt newint8(void)
{
   count++;
//   asm {
//        MOV AL,20h
//        OUT 20h,AL
//       }

   outportb(0x20, 0x20);

} // newint8(void)

void interrupt (*int8save)(void);

void mydelay(int n)
{
   char value;
//        asm {
//          CLI
//          PUSH AX
//          MOV AL,036h
//          OUT 43h,AL
//          MOV AX,11932
//          OUT 40h,AL
//          MOV AL,AH
//          OUT 40h,AL 
//          POP AX
//        } // asm

  outportb( 0x43, 0x36);
  value = (11932 & 0xFF);
  outportb( 0x40, value);
  value = (11932 / 256);
  outportb( 0x40, value);


    int8save = getvect(8);
    setvect(8,newint8);
 //   asm  { STI};
    count = 0;
    while(count <= n*100)
        ;

   //     asm {
   //       CLI
   //       PUSH AX
   //       MOV AL,036h
   //       OUT 43h,AL
   //       MOV AX,0
   //       OUT 40h,AL
   //       MOV AL,AH
   //       OUT 40h,AL 
   //       POP AX
   //     } // asm

   outportb( 0x43, 0x36);
   outportb( 0x40, 0);
   outportb( 0x40, 0);


    setvect(8,int8save);


} //mydelay



/*------------------------------------------------
 ChangeSpeaker - Turn speaker on or off. */

 void ChangeSpeaker( int status )
 {
  int portval;

      portval = 0;

//   asm {
//        PUSH AX
//        IN AL,61h
//        MOV byte ptr portval,AL
//        POP AX
 //      }

   portval = inportb( 0x61 );


    if ( status==ON )
     portval |= 0x03;
      else
       portval &=~ 0x03;
//        asm {
//          PUSH AX
//          MOV AX,portval
//          OUT 61h,AL
//          POP AX
//        } // asm

        outportb( 0x61, portval );

	} /*--ChangeSpeaker( )----------*/

	void Sound( int hertz )
	{
	 unsigned divisor = 1193180L / hertz;

	  ChangeSpeaker( ON );

   //     asm {
   //       PUSH AX
   //       MOV AL,0B6h
   //       OUT 43h,AL
   //       POP AX
   //     } // asm

           outportb( 0x43, 0xB6 );


   //     asm {
   //       PUSH AX
   //       MOV AX,divisor
   //       AND AX,0FFh
   //       OUT 42h,AL
   //       POP AX
   //     } // asm

        outportb( 0x42, divisor & 0xFF ) ;



//        asm {
//          PUSH AX
//          MOV AX,divisor
//          MOV AL,AH
//          OUT 42h,AL
//          POP AX
//        } // asm

             outportb( 0x42, divisor >> 8 ) ;

	     } /*--Sound( )-----*/

      void NoSound( void )
        {
             ChangeSpeaker( OFF );
        } /*--NoSound( )------*/

       int main( void )
        {
           Sound( 355 );
           mydelay( 3 );
           Sound( 733 );
           mydelay( 3 );
           Sound( 355 );
           mydelay( 3 );
           Sound( 733 );
           mydelay( 3 );

           NoSound( );
           return(0);
        } /*--main( )-------*/
