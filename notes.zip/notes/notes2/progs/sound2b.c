// sound2b.c
#include <dos.h>
#include <stdio.h>

#define ON (1)
#define OFF (0)

volatile int count;

void interrupt newint8(void)
{
   count++;
 
outportb(0x20, 0x20);

} // newint8(void)

void interrupt (*int8save)(void);

void mydelay(int n)
{

  char value;
   
  outportb( 0x43, 0x16);
  value = (11932 & 0xFF);
  outportb( 0x40, value);

  outportb( 0x43, 0x26);
  value = (11932 / 256);
  outportb( 0x40, value);

    int8save = getvect(8);
    setvect(8,newint8);
    count = 0;
    while(count <= n*100)
        ;

   outportb( 0x43, 0x16);
   outportb( 0x40, 0);

   outportb( 0x43, 0x26);
   outportb( 0x40, 0);

    setvect(8,int8save);


} //mydelay



/*------------------------------------------------
 ChangeSpeaker - Turn speaker on or off. */

 void ChangeSpeaker( int status )
 {
  int portval;

      portval = 0;


   portval = inportb( 0x61 );


    if ( status==ON )
     portval |= 0x03;
      else
       portval &=~ 0x03;
    
   outportb( 0x61, portval );
  

	} /*--ChangeSpeaker( )----------*/

	void Sound( int hertz )
	{
	 unsigned divisor = 1193180L / hertz;

	  ChangeSpeaker( ON );


      outportb( 0x43, 0x96 );



    outportb( 0x42, divisor & 0xFF ) ;




 outportb( 0x43, 0xA6 ) ;


       outportb( 0x42, divisor >> 8 ) ;

	     } /*--Sound( )-----*/

      void NoSound( void )
        {
             ChangeSpeaker( OFF );
        } /*--NoSound( )------*/

       int main( void )
        {
           Sound( 355 );
           mydelay( 2 );
           Sound( 733 );
           mydelay( 2 );
           Sound( 355 );
           mydelay( 2 );
           Sound( 733 );
           mydelay( 2 );

           NoSound( );
           return(0);
        } /*--main( )-------*/
