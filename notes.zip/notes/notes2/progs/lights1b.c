
// lights1b.c

#include <dos.h>
#include <stdio.h>

#define SCROLL 1
#define NUMS 2
#define CAPS 4




char LIGHTS[] = {NUMS, CAPS, SCROLL, CAPS, NUMS, CAPS+SCROLL, NUMS+CAPS, 
                             NUMS+SCROLL,  NUMS+SCROLL+CAPS, 0};

int main(int argc, char *argv[])
{

  char al;
  int  i, n;
  long int j;

i = 0;

if (argc == 1)
   n = 3;
else
   sscanf(argv[1], "%d", &n);

do {

     outportb(0x60, 0xED);
         

      al = LIGHTS[i];

     outport(0x60, al);


     sleep(n);    

       i++;


   } while( i < 12);

return 0;

} // main



