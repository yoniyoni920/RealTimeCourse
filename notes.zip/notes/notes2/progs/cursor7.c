//;
//; Cursor7.c
//;
//;This program demonstrates cursor manipulation.
//;
//;

#include <stdio.h>
#include <dos.h>
#include <conio.h>




//Data               SEGMENT PARA PUBLIC 'Data'
//CursorPos          DW      0     ; NUMBER OF LINES SCROLLED DOWN
//Base               DW      0
//Cursor_Sizes       DW      000Fh,0E0Fh,0001h,000Fh,010Fh,020Fh,030Fh,040Fh
//                   DW      050Fh,060Fh,070Fh,080Fh,090Fh,0A0Fh,0B0Fh,0C0Fh
//                   DW      0D0Fh,0E0Fh,000Eh,010Eh,020Eh,030Eh,040Eh,050Eh
//                   DW      060Eh,070Eh,080Eh,090Eh,0A0Eh,0B0Eh,0C0Eh,0D0Eh
//                   DW      0C0Dh,0B0Dh,0A0Dh,090Dh,080Dh,070Dh,060Dh,050Dh
//                   DW      040Dh,030Dh,020Dh,010Dh,010Ch,020Ch,030Ch,040Ch
//                   DW      050Ch,060Ch,070Ch,080Ch,090Ch,090Ch,0A0Ch,0B0Ch
//                   DW      0A0Bh,090Bh,080Bh,070Bh,060Bh,050Bh,040Bh,030Bh
//                   DW      020Bh,010Bh,010Ah,020Ah,030Ah,040Ah,050Ah,060Ah
//                   DW      070Ah,080Ah,090Ah,0809h,0709h,0609h,0509h,0409h
//                   DW      0309h,0209h,0109h,0108h,0208h,0308h,0408h,0508h
//                   DW      0708h,0607h,0507h,0407h,0307h,0207h,0107h,0106h
//                   DW      0608h,0206h,0306h,0406h,0506h,0405h,0305h,0205h
//                   DW      0104h,0204h,0304h,0203h,0103h,0203h,0102h,0002h
//                   DW      0105h,0001h

int CursorPos;
int Base;
int Cursor_Sizes[]  = {0x000F,0x0E0F,0x0001,0x000F,0x010F,0x020F,0x030F,0x040F,
                         0x050F,0x060F,0x070F,0x080F,0x090F,0x0A0F,0x0B0F,0x0C0F,
                         0x0D0F,0x0E0F,0x000E,0x010E,0x020E,0x030E,0x040E,0x050E,
                         0x060E,0x070E,0x080E,0x090E,0x0A0E,0x0B0E,0x0C0E,0x0D0E,
                         0x0C0D,0x0B0D,0x0A0D,0x090D,0x080D,0x070D,0x060D,0x050D,
                         0x040D,0x030D,0x020D,0x010D,0x010C,0x020C,0x030C,0x040C,
                         0x050C,0x060C,0x070C,0x080C,0x090C,0x090C,0x0A0C,0x0B0C,
                         0x0A0B,0x090B,0x080B,0x070B,0x060B,0x050B,0x040B,0x030B,
                         0x020B,0x010B,0x010A,0x020A,0x030A,0x040A,0x050A,0x060A,
                         0x070A,0x080A,0x090A,0x0809,0x0709,0x0609,0x0509,0x0409,
                         0x0309,0x0209,0x0109,0x0108,0x0208,0x0308,0x0408,0x0508,
                         0x0708,0x0607,0x0507,0x0407,0x0307,0x0207,0x0107,0x0106,
                         0x0608,0x0206,0x0306,0x0406,0x0506,0x0405,0x0305,0x0205,
                         0x0104,0x0204,0x0304,0x0203,0x0103,0x0203,0x0102,0x0002,
                         0x0105,0x0001 };


//;
//Data               ENDS
//Cseg               SEGMENT PARA PUBLIC 'Code'
//                   .386  ; Enable 386 commands
//SetCursorPos          PROC    NEAR
//; Set Cursor to position in BX
//; Input: BX
//; Output: None
//;
//  ; 3D4H  GRAPHICS ADAPTER ADDRESS REGISTER PORT
//  ; 3D5H  GRAPHICS ADAPTER DATA REGISTER PORT

//;
//  MOV              DX,3D4H  ; POINT TO 3D4H - 3D5H PORT PAIR
//  MOV              AL,14    ; ADDRESS OF CURSOR REGISTER POS HIGH BYTE
//  MOV              AH,BH    ; GET DESIRED VALUE OF CURSOR POS HIGH BYTE
//  OUT              DX,AX    ; PORT(3D4h) = 14, PORT(3D5h) = VALUE OF BH

void SetCursorPos(int pos)
{
 int ax;

ax = 14 +  ((pos) & (0xFF00));

outport(0x3D4, ax);



ax = 15 +  (pos & (0xFF))*256  ;

outport(0x3D4, ax);


} // SetCursorPos


//;
//  MOV              AL,15    ; ADDRESS OF CURSOR REGISTER POS HIGH BYTE
//  MOV              AH,BL    ; GET DESIRED VALUE OF CURSOR POS LOW BYTE
//  OUT              DX,AX    ; PORT(3D4h) = 15, PORT(3D5h) = VALUE OF BL
//;
//  RET                       ; Return to caller
//SetCursorPos          ENDP
;
//SetCurSize      PROC  NEAR
//;
//; Cursor High level assumed in AH, Low level in AL
//;
//;
//    PUSH            AX
//    MOV             DX,3D4h  ; POINT TO 3D4H - 3D5H PORT PAIR
//    MOV             AL,0Ah ; CURSOR START ADDRESS (0Ah) 
//    OUT             DX,AX    ; PORT(3D4h) = 0Ah, PORT(3D5h) = 01h
//    POP             AX
//    PUSH            AX
//    MOV             AH,AL
//    MOV             AL,0Bh ; CURSOR END ADDRESS -
//    OUT             DX,AX    ; PORT(3D4h) = 0Bh, PORT(3D5h) = 0Eh
//    POP             AX
//    RET
//SetCurSize        ENDP

void SetCurSize(int currsize)
{
 int ax;


ax = 10  + (currsize & 0xFF00);
outport(0x3D4, ax);

ax = 11  + (currsize & 0xFF)*256 ;
outport(0x3D4, ax);


} // SetCurSize

int main()
{

  int  far *b800h;
  int value, i, ax, flag, si, ch1;
  union REGS regs;


//;
//Start              PROC    FAR
//;
//;STANDARD PROGRAM PROLOGUE
//;
//  ASSUME           CS:Cseg
//  PUSH             DS          ; SAVE PSP SEGMENT ADDRESS
//  MOV              AX,0
//  PUSH             AX          ; SAVE RET ADDRESS OFFSET (PSP+0)
//  MOV              AX,DATA
//  MOV              DS,AX       ; ESTABLISH DATA SEGMENT ADDRESSABILITY
//  ASSUME           DS:Data
//;
//;PART1 : INITIALIZE THE DISPLAY ADAPTER
//;

//  MOV              AH,0          ; SELECT FUNCTION = 'SET MODE'
//  MOV              AL,1          ; 40 BY 25 COLOR IMAGE
//  INT              10H           ; ADAPTER INITIALIZED. PAGE 0 DISPLAYED
//;

  regs.h.ah = 0;
  regs.h.al = 1;
  int86(0x10, &regs, &regs);
 



//  MOV              AX,0B800H     ; SEGMENT ADDRESS OF MEMORY ON COLOR ADAPTER
//;
//  MOV              ES,AX         ; SET UP EXTRA SEGMENT REGISTER
//  MOV              DI,0          ; INITIAL OFFSET ADDRESS INTO SEGMENT
//  MOV              AL,' '        ; CHARACTER SPACE TO FILL ADAPTER MEMORY
//  MOV              AH,0Eh        ; ATTRIBUTE BYTE : INTENSE YELLOW
//  MOV              CX,1000       ; INITIALIZE COUNT, 1 SCREEN
//  CLD                            ; WRITE FORWARD
//  REP              STOSW         ; WRITE
//;
//; WRITE 'A' IN MID SCREEN
//;
//  MOV              BYTE PTR ES:[2*(12*40+20)],'A'
//;

 ((unsigned long int)b800h) = 0xB800 * 65536; 

   value = ' ' + 256*14;  // space + ATTRIBUTE BYTE : INTENSE YELLOW BLACK BACKGROUND


for(i=0; i < 1000; i++)
  {
    b800h[i] = value;
  } // for

b800h[12*40+20] = b800h[12*40+20]  + 'A' - ' '; 

//; SET THE CURSOR ADDRESS REGISTERS
//;
//  MOV              BX,12*40+20
//  CALL             SetCursorPos
//;
//;PART 2 : Wait for key strike

SetCursorPos(12*40+20);

//  MOV              SI,0
//NextLoop:
//;

si = 0;

//  MOV     AX,Cursor_Sizes[SI]
//  CALL    SetCurSize
// ADD     SI,2
//  CMP     SI,228
//  JNE     Skip1
//  MOV     SI,0



while(1)
{
   ax = Cursor_Sizes[si];
   SetCurSize(ax);
   si++;
   if (si >= 114)
    si = 0;
 
//Skip1:


//;
//; Wait for key
//;
//  MOV              AH,0       ; WAIT AND READ KEY
//  INT              16h        ;
//  CMP              AH,1       ; Is it Esc?
//  JE               ToReturn   ; Yes - Return to DOS
//;
//;  NOT ESC KEY - CHANGE CURSOR
//;
//  JMP              NextLoop   ; REPEAT MAIN LOOP
//;

  regs.h.ah = 0;
  int86(0x16, &regs, &regs);
  if (regs.h.ah == 1)
      break;

} // while(1)

//ToReturn:
//                   MOV  AX,2
//                   INT  10h
//                   RET
//Start              ENDP
//Cseg               ENDS
//  END              START

  regs.h.ah = 0;
  regs.h.al = 2;
  int86(0x10, &regs, &regs);
 

} // main