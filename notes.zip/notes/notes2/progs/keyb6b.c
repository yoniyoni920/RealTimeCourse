// key6a.c

#include <stdio.h>
#include <dos.h>
#include <conio.h>

char ScanTable[] = { 0,1,'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=',8,0,
	  'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '[', ']',13,0,
	   'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ';',0,0,0,0,
	   'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',','.', '/',0,0,0,
	   ' ',0,0,0,0,0,0,0,0,0,0,0,0,0,
	   '7', '8', '9', '-', '4', '5', '6', '+', '1', '2', '3', '0', '.' };

char buffer;
int buffer_flag;

void interrupt Kbint(void);
void interrupt (*SaveInt9Isr)(void); // pointer to function


int main()
{
  SaveInt9Isr = getvect(9);
  buffer_flag = 0;
  setvect(9, Kbint);
  buffer = 0;
  while(buffer != 1)
   {
     while(buffer_flag == 0 )
                ;
     if (buffer != 1)
      {
         printf("%c", buffer);
         if (buffer == 13) // Was it carrige return?
            printf("%c", 10); // Yes it was, we must also display a line feed
      }  // if
    buffer_flag = 0;
   } // while

   setvect(9, SaveInt9Isr);

return 0;

} // main


void interrupt Kbint(void)
{
  char scan_code, ascii_code, al;


   
  scan_code = inportb(0x60);
  al = inportb(0x61);
  al = al | 0x80;
  outportb(0x61, al);
  al = al & 0x7F;
  outportb(0x61, al);
  

if ((scan_code & 0x80) != 0 ) // Is it a key being released?
     ; // we ignore those
else
{
  buffer = ScanTable[scan_code];
  if (buffer != 0) // is it an ascii key?
    buffer_flag = 1;
} // else

// Signal End Of Interrupt (EOI) to 8259 command register


outportb(0x20, 0x20);


} // Kbint

