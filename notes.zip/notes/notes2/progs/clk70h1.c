/* clk70h1.c */

#include <stdio.h>
#include <dos.h>



int  convert_to_binary(int x)
{
 int i;
 int temp, scale, result;
 

  temp =0;
  scale = 1;
  for(i=0; i < 4; i++)
   {
     temp = temp + (x % 2)*scale;
     scale *= 2;
     x = x >> 1;
   } // for

  result = temp;
  temp = 0;

  scale = 1;
  for(i=0; i < 4; i++)
   {
     temp = temp + (x % 2)*scale;
     scale *= 2;
     x = x >> 1;
   } // for

  temp *= 10;
  result = temp + result;
  return result;

} // convert_to_binary

volatile int global_flag;

void interrupt (*old0x70isr)(void);

int count = 0;

void interrupt new0x70isr(void)
{
  char port70hsave;

  count++;
 if (count == 1000)
 {
  global_flag = 1;
  count = 0;
 } // if
 
 //asm {
  // PUSH AX
  // PUSH BX
  // IN AL,70h   // Read existing port 70h
  // MOV BX,AX

   // MOV AL,0Ch  // Set up "Read status register C"
   // OUT 70h,AL  //
   // MOV AL,8Ch  //
   // OUT 70h,AL  //
   // IN AL,71h
   // MOV AX,BX   //  Restore port 70h
   //OUT 70h,AL  //

 port70hsave = inportb( 0x70 );
 outportb( 0x70, 0xC );
 outportb( 0x70, 0x8C );
 inportb( 0x71 );
 outportb( 0x70, port70hsave );
 

//   MOV AL,20h   // Set up "EOI" value  
//   OUT 0A0h,AL  // Notify Secondary PIC
//   OUT 020h,AL  // Notify Primary PIC

 outportb( 0xA0, 0x20 );
 outportb( 0x20, 0x20 );




  // POP BX
  // POP AX

  //} // asm */


} // new0x70isr

void readclk(char str[])
{
  int i;
  int hour, min, sec;


  hour = min = sec = 0;

//  asm {
//   PUSH AX
//   MOV AL,0
//   OUT 70h,AL
//   IN AL,71h
//   MOV BYTE PTR sec,AL
//

 outportb( 0x70, 0);
 ((char)sec)  = inportb( 0x71 );

//   MOV AL,2
//   OUT 70h,AL
//   IN AL,71h
//   MOV BYTE PTR min,AL
//

 outportb( 0x70, 2);
 ((char)min)  = inportb( 0x71 );


//   MOV AL,4
//   OUT 70h,AL
//   IN AL,71h
//   MOV BYTE PTR hour,AL
//
//   POP AX
//  } // asm

 outportb( 0x70, 4);
 ((char)hour)  = inportb( 0x71 );


  sec = convert_to_binary(sec);
  min = convert_to_binary(min);
  hour = convert_to_binary(hour);

  sprintf(str,"%2d:%2d:%2d", hour, min, sec);

} // readclk

int main()
{
  char str[16], al;
  int local_flag = 1, x71h1=0, x71h2=0, x71h3;
  char old_0A1h_mask, old_70h_A_mask, new_0A1h_mask, new_70h_mask;
  struct REGPACK regpack;
  union REGS regs;

  old0x70isr = getvect(0x70);
  setvect(0x70, new0x70isr);

//  asm {
//   CLI         // Disable interrupts
//   PUSH AX     // Interrupt may occur while updating

//   IN AL,0A1h  // Make sure IRQ8 is not masked
//   MOV old_0A1h_mask,AL
//   AND AL,0FEh // Set bit 0 of port 0A1 to zero
//    OUT 0A1h,AL //

 old_0A1h_mask = inportb( 0xA1 );
 new_0A1h_mask  = old_0A1h_mask & 0xFE;
 outportb( 0xA1, new_0A1h_mask ) ;

//   IN AL,70h   // Set up "Write into status register A"
//   MOV AL,0Ah  //
//   OUT 70h,AL  //

  inportb(0x70);
 outportb( 0x70, 0xA ) ;

//   MOV AL,8Ah  //
//   OUT 70h,AL  //

 inportb(0x70);
 outportb( 0x70, 0x8A ) ;


//   IN AL,71h   //
//   MOV BYTE PTR x71h1,AL  // Save old value
//   MOV old_70h_A_mask,AL

al  = inportb(0x71);
x71h1 = al;
old_70h_A_mask = al;


//   AND AL,11110000b // Change only Rate
//   OR AL,0110b // Make sure it is Rate =0110 (1Khz)
//   OUT 71h,AL  // Write into status register A
//  IN AL,71h   // Read to confirm write

al = al & 0xF0;
al = al | 6;
outportb( 0x71, al );


//   IN AL,70h  // Set up "Write into status register B"
//   MOV AL,0Bh //
//   OUT 70h,AL //
//   MOV AL,8Bh //
//   OUT 70h,AL //

 inportb(0x70);
 outportb( 0x70, 0xB ) ;
 outportb( 0x70, 0x8B ) ;


//   IN AL,71h  //
//   MOV BYTE PTR x71h2,AL // Save Old value

al = inportb(0x71);

//   AND AL,8Fh // Mask out PI,AI,UI

al = al & 0x8F;

//   OR AL,40h  // Enable periodic interrupts (PI=1) only

al = al | 0x40;

//   OUT 71h,AL // Write into status register  B
//   IN AL,71h  // Read to confirm write
//   MOV byte ptr x71h3,AL // Save old value

outportb(0x71, al);


//   IN AL,021h  // Make sure IRQ2 is not masked
//   AND AL,0FBh // Write 0 to bit 2 of port 21h
//   OUT 021h,AL // Write to port 21h

al = inportb(0x21);
al = al & 0xFB;
outportb(0x21, al);

//   IN AL,70h  // Set up "Read into status resister C"
//   MOV AL,0Ch // Required for for "Write into port 71h"
//   OUT 70h,AL

   al = inportb(0x70);
   al = 0xC;
   outportb(0x70, al);


//   IN AL,70h
//   MOV AL,8Ch // 
//   OUT 70h,AL
//   IN AL,71h  // Read status register C 
              // (we do nothing with it)

   inportb(0x70);
   al = 0x8C;
   outportb(0x70, al);


//   IN AL,70h  // Set up "Read into status resister C"
//   MOV AL,0Dh // Required for for "Write into port 71h"
//   OUT 70h,AL
//   IN AL,70h
//   MOV AL,8Dh
//   OUT 70h,AL
//   IN AL,71h  // Read status register D 
              // (we do nothing with it)

   inportb(0x70);
   al = 0xD;
   outportb(0x70, al);
   inportb(0x70);
   al = 0x8D;
   outportb(0x70, al);


 //  STI
 //  POP AX

  //} // asm

  printf("x71h1 = %x, x71h2 = %x, x72h3  = %x\n", x71h1, x71h2, x71h3);

  while(local_flag)
  {


    putchar(13);
    global_flag = 0;
    while(global_flag == 0) // Wait for interrupt
         ;                  // Do not print all the time
    readclk(str);
    printf(str);
    //asm {
    //    PUSH AX   // Press any key to terminate
    //    MOV AH,1  // Check If key has been pressed
    //    INT 16h   //
    //    PUSHF
    //    POP AX
    //    AND AX,64 // isolate zf 
    //    MOV local_flag,AX
      //  POP AX

    //} // asm

   regpack.r_ax = 256;
   intr(0x16, &regpack);
   local_flag = ((regpack.r_flags & 64) != 0);
 
  } // while


 //   asm {
 //         PUSH AX   // Cancel key pressed
 //         MOV AH,0
 //         INT 16h
 //         POP AX
 //       }  // asm

    regs.h.ah = 0;
    int86(0x16, &regs, &regs);


  //  asm {
  //      MOV AL,old_0A1h_mask
  //      OUT 0A1h,AL

  outportb(0xA1, old_0A1h_mask);

    
   // IN AL,70h  // restore A status register

   inportb(0x70);

   //     MOV AL,0Ah
   //     OUT 70h,AL

   al = 0xA;
   outportb(0x70, al);

   //     MOV AL,8Ah
   //     OUT 70h,AL

   al = 0x8A;
   outportb(0x70, al);



   //     IN AL,71h
   //     MOV AL,old_70h_A_mask
   //     OUT 71h,AL
   //     IN AL,71h

   inportb(0x71);
   outportb(0x71, old_70h_A_mask);



 //   } // asm
    setvect(0x70, old0x70isr);


}  // main

