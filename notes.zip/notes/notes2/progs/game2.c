// game5.c

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>

char screen_tab[25][80];
char display[25*80+1]= {0};

int height = 3;

void draw_plane(int row)
{
 int i, j, k;

 for(i=0; i < 80; i++)
   screen_tab[row][i] = '*';

 {
   row--;
   for(i=10; i < 70; i++)
     screen_tab[row][i] = '*';

 } // for

 {
   row--;
   for(i=30; i < 50; i++)
     screen_tab[row][i] = '*';

 } // for

 {
   row--;
   for(i=35; i < 45; i++)
     screen_tab[row][i] = '*';

 } // for

 {
   row--;
     screen_tab[row][39] = '*';
     screen_tab[row][40] = '*';

 } // for


} // draw_plane

int pos = 0, disp =5;
int runway_length=9, pas_length=3, horizon_length=9, visible_dist=2;

void set_attributes()
{
  if (height == 1)
  {
   runway_length=14;
   pas_length=6; 
   horizon_length=15; 
   visible_dist=4;
  } // if
  else
  if (height == 2)
  {
   runway_length=12;
   pas_length=5; 
   horizon_length=12; 
   visible_dist=3;
  } // if
  else
  if (height == 3)
  {
   runway_length=9;
   pas_length=3; 
   horizon_length=9; 
   visible_dist=2;
  } // if
  else
  if (height == 4)
  {
   runway_length=7;
   pas_length=2; 
   horizon_length=7; 
   visible_dist=1;
  } // if
  else
  if (height == 5)
  {
   runway_length=5;
   pas_length=1; 
   horizon_length=5; 
   visible_dist=0;
  } // if


} // set_attributes()

void draw_runway()
{
  int i, j, k=0, m=4;

  for(i=0; i< horizon_length; i++)
  {
   screen_tab[8+i+pos][40-runway_length+k+disp] = '.';
   screen_tab[8+i+pos][40+runway_length-k+disp] = '.';
   if( (k %m) == 0)
    if (m > 3) 
      m--;
    else;    
   else
   if (i >= visible_dist)
   for(j=0; j < pas_length-k; j++)
   {
     screen_tab[8+i+pos][40-j+disp] = '"';
     screen_tab[8+i+pos][40+j+disp] = '"';     
   } // for
   k--;
  } // for
   pos++;
   if (pos == 4)
    pos =0;


} // draw_runway()

void erase_screen_tab()
{
  int i, j;

   for(i=0; i < 25; i++)
     for(j=0; j < 80; j++)

     screen_tab[i][j] = ' ';


} // erase_screen_tab()

void copy_to_display()
{
 int i,j,k;

 for(i=0; i < 25; i++)
   for(j=0; j < 80; j++)
   display[i*80+j] = screen_tab[i][j]; 


} //copy_to_display() 


 int scan_code = 0;


int main()
{
 while(1)
 {
  asm{
   MOV AH,1
   INT 16h
   JZ Skip
    MOV AH,0
    INT 16h
    MOV BYTE PTR scan_code,AH
   }

   if ((scan_code == 72) && (height < 5))
     height++;
   else
   if ((scan_code == 80) && (height > 1))
     height--;
   else
   if ((scan_code == 75) && (disp < 10))
     disp++;
   else
   if ((scan_code == 77) && (disp > -10))
     disp--;
   else
      if (scan_code == 1) 
      {
       asm{
        MOV AH,4Ch
        INT 21h
       }
      } // if
    
   Skip:

  erase_screen_tab();
  set_attributes();
  draw_plane(24);
  draw_runway();
  copy_to_display();
  printf("%s", display);
  delay(300);


 } // while


} // main
