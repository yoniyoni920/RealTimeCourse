/* count.c  - count machine instructions 
   Pure C version.   */

#include <stdio.h>
#include <dos.h>

volatile int Machine_Ins_Count;

void interrupt (*Int1Save) (void);  /* Pointer to function */

void interrupt Single_Step_Handler(void)
   {
    Machine_Ins_Count++;
   } /* Single_Step_Handler */


void Start_Machine_Count()
{

   Int1Save = getvect(1);               /* Preserve old pointer */
   setvect(1, Single_Step_Handler); /* Set entry to new handler */

  Machine_Ins_Count = 0;

  asm {
     PUSHF
     POP AX
     OR AX,100000000B
     PUSH AX
     POPF
  } /* asm */

} /* Start_Machine_Count */

unsigned int Return_Machine_Count()
{

  /* Turn off  TF*/
  asm {
     PUSHF
     POP AX
     AND AX,1111111011111111B
     PUSH AX
     POPF
  } /* asm */

   setvect(1, Int1Save); /* Set entry to new handler */

  return Machine_Ins_Count;


} /* Return_Machine_Count */


void main(void)
 {
  unsigned int i, j, z, count;
  
  Start_Machine_Count();
  z = 0;
  for(i=0; i < 10; i++)
    for(j=0; j < 10; j++)
      z = z + i*j;

  count = Return_Machine_Count();

  printf("No of machine instructions executed: %u\n", count); 
  Start_Machine_Count();
  z = 0;
  for(i=0; i < 5; i++)
    for(j=0; j < 5; j++)
      z = z + i*j;

  count = Return_Machine_Count();

  printf("No of machine instructions executed: %u\n", count); 

 } /* main */

