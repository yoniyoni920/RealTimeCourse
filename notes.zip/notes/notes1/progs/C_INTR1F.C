/* c_intr1f.c - Change keyboard key interrupt handler.
   Pure C version.   */

#include <stdio.h>
#include <dos.h>

volatile int Keystroke_Flag;
int count;
void interrupt (*Int9Save) (void);  /* Pointer to function */

void interrupt Keystroke_Handler(void)
   {
	 (*Int9Save)();
	 count++;
	 if (count ==4)
     Keystroke_Flag = 1;
     printf("C: keyboard key has been pressed or released.\n");
   } /* Keystroke_Handler */

void main(void)
 {
   long int *lptr;

   lptr = (void interrupt *)36;
//   Int9Save = getvect(9);               /* Preserve old pointer */

   Int9Save = (void interrupt *)(*lptr);               /* Preserve old pointer */

//   setvect(9, Keystroke_Handler);       /* Set entry to new handler */

   ((void interrupt *)(*lptr)) = Keystroke_Handler;

   printf("C: Press keyboard key to continue.\n");

   Keystroke_Flag = 0;
   count = 0;
   while (Keystroke_Flag == 0)
       ;   /* Do nothing */

   printf("C: Terminating ...\n");

//   setvect(9,Int9Save);               /* Restore old pointer */

   ((void interrupt *)(*lptr)) = Int9Save;


 } /* main */

