/* dem_key10.c - Change Ctrl-Break interrupt handler.
   Pure C version.   */

#include <stdio.h>
#include <dos.h>

volatile int scan_code;
volatile int Int9_flag;

void interrupt (*Int9Save) (void);  /* Pointer to function */

void interrupt Int9_Handler(void)
   {
  //     asm{
  //     PUSH AX
  //     MOV AX,0
  //     IN AL,60h
  //     TEST AL,80h
  //     JNZ Skip2
  //     MOV WORD PTR scan_code,AX
  //     MOV Int9_flag,1
  //   }

  scan_code = inportb(0x60);
  if ((scan_code & 32768) != 0)
        Int9_flag = 1;

  al = inportb(0x61);
  al = al | 0x80;
  outportb(0x61, al);
  al = al & 0x7F;
  outportb(0x61, al);
  

    Skip2:
 //    asm {
 //      PUSHF
 //      CALL  DWORD PTR Int9Save
 //      POP AX
 //    }

(*Int9Save) ();

   } /* Int9_Handler */

void main(void)
 {
  struct REGPACK regpack;

   Int9Save = getvect(9);           /* Preserve old pointer */
   setvect(9, Int9_Handler);        /* Set entry to new handler */

   do {
        Int9_flag = 0;  
        printf("Press any key (almost)\n:");

         while (Int9_flag == 0)
          ;   /* Do nothing */
       
        printf("You pressed key assigned"
              " scan code = %d\n", scan_code);

//       asm {          // Erase character if 16h
//         MOV AH,1     // recognises it
//         INT 16h
//         JZ Skip3
//            MOV AH,0
//            INT 16h
//       } // asm
//      Skip3:

regpack.r_ax = 256;
intr(0x16, &regpack);
if ( (regpack.r_flags & 64) == 0)
  {
   // Read key
    regs.h.ah = 0;
    int86(0x16, &regs, &regs);

  } // if
    

     } while(scan_code != 1);


   setvect(9,Int9Save);               /* Restore old pointer */

 } /* main */

