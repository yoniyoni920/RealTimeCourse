/* demkey5a.c - demostrate use of int 16h, AH = 2, including aux byte. */

#include <stdio.h>
#include <dos.h>

typedef struct status_byte
{
  unsigned int right_shift_key : 1;
  unsigned int left_shift_key : 1;
  unsigned int ctrl_key : 1;
  unsigned int alt_key : 1;
  unsigned int scroll_lock_on : 1;
  unsigned int num_lock_on : 1;
  unsigned int caps_lock_on : 1;
  unsigned int insert_mode_on : 1;
}  STATUS_BYTE, far *STATUS_BYTE_PTR;

typedef struct aux_byte
{
  unsigned int unused : 3;
  unsigned int hold_on : 1; /* ctrl-num lock */
  unsigned int scroll_lock_depressed : 1;
  unsigned int num_lock_depressed : 1;
  unsigned int caps_lock_depressed : 1;
  unsigned int insert_key_depressed : 1;
}  AUX_BYTE, far *AUX_BYTE_PTR;


void main(void)
 {

   STATUS_BYTE sbyte, sbyte1, far *temp_ptr;
   char *p, *p1, temp;
   AUX_BYTE  abyte;
   union REGS regs;
   STATUS_BYTE_PTR sbyte_ptr;
   AUX_BYTE_PTR abyte_ptr;


     regs.h.ah = 2;
     int86(0x16, &regs, &regs);
     temp = regs.h.al;
     temp_ptr = (STATUS_BYTE_PTR) &temp; 
     sbyte =  *temp_ptr;
     abyte_ptr = (AUX_BYTE_PTR)0x417;
     sbyte_ptr = (STATUS_BYTE_PTR)0x418;
    abyte = *abyte_ptr;
    sbyte1 = *sbyte_ptr;

   p = (char *) &sbyte;
   p1 = (char *) &sbyte1;


   printf("\n sbyte = %d, sbyte1 = %d\n", (int) *p, (int) *p1);


   printf("\nKeyboard status:\n\n");
   printf("Right shift: %d,\nLeft shift: %d,\nCtrl key: %d,\nAlt key: %d,\n",
            (unsigned int) sbyte.right_shift_key,
              (unsigned int) sbyte.left_shift_key,
                (unsigned int) sbyte.ctrl_key,
                  (unsigned int) sbyte.alt_key);

   printf("Scroll lock on: %d,\nNum lock on: %d,"
      "\nCaps Lock on: %d,\nInsert mode: %d",
            (unsigned int) sbyte.scroll_lock_on,
              (unsigned int) sbyte.num_lock_on,
                (unsigned int) sbyte.caps_lock_on,
                  (unsigned int) sbyte.insert_mode_on);
   putchar('\n');

   printf("\nAuxilary byte:\n\n");
   printf("Hold on: %d,\nScroll lock dep: %d,\nNum lock dep: %d,"
               "\nCaps Lock dep: %d,\nInsert key dep: %d",
            (unsigned int) abyte.hold_on,
            (unsigned int) abyte.scroll_lock_depressed,
              (unsigned int) abyte.num_lock_depressed,
                (unsigned int) abyte.caps_lock_depressed,
                  (unsigned int) abyte.insert_key_depressed);
   putchar('\n');

 } /* main */
