/* dem_key9.c - Change Ctrl-Break interrupt handler.
   Pure C version.   */

#include <stdio.h>
#include <dos.h>

volatile int scan_code;
volatile int Int9_flag;

void interrupt (*Int9Save) (void);  /* Pointer to function */

void interrupt Int9_Handler(void)
   {
       asm{
       PUSH AX
       MOV AX,0
       IN AL,60h
       TEST AL,80h
       JNZ Skip2
       MOV WORD PTR scan_code,AX
       MOV Int9_flag,1
     }
    Skip2:
     asm {
       PUSHF
       CALL  DWORD PTR Int9Save
       POP AX
     }


   } /* Int9_Handler */

void main(void)
 {
   Int9Save = getvect(9);           /* Preserve old pointer */
   setvect(9, Int9_Handler);        /* Set entry to new handler */

   do {
        Int9_flag = 0;  
        printf("Press any key (almost)\n:");

         while (Int9_flag == 0)
          ;   /* Do nothing */
       
        printf("You pressed key assigned"
              " scan code = %d\n", scan_code);

       asm {          // Erase character if 16h
         MOV AH,1     // recognises it
         INT 16h
         JZ Skip3
            MOV AH,0
            INT 16h
       } // asm
      Skip3:



     } while(scan_code != 1);


   setvect(9,Int9Save);               /* Restore old pointer */

 } /* main */

