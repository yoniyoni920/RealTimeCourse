/* dem_key3.c - demostrate use of int 16h, AH = 0  */

#include <stdio.h>
#include <dos.h>

void main(void)
 {

   unsigned int scan_code;
   char scan_temp, inp_char;
   union REGS regs;

   printf("\nPress ESC to exit program\n");

   do {
	printf("Press any key (almost)\n:");


	  regs.h.ah = 0;
          int86(0x16, &regs, &regs);
	  scan_temp = regs.h.ah;
	  inp_char = regs.h.al;


	scan_code = (unsigned int) scan_temp;

	if (scan_code == 1)
	    printf("You pressed ESC, \n");

	printf("You pressed key assigned"
              " scan code = %d, char_value= '%c'\n",
				    scan_code,  inp_char);


     } while(!(scan_code == 1));


 } /* main */
