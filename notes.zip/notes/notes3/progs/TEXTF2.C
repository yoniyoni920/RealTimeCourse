// textf2.c

#include <stdio.h>

char fname[80] = "t3.txt\0";
 int fd;
  int c, flag;


int main(int argc, char *argv[])
{
 // FILE *fp;


//  fp = fopen(argv[1], "wt");

  asm {
      PUSH CX
      PUSH AX
      PUSH DX

      MOV CX,0
      MOV DX,offset fname
      MOV AH,3Ch
      INT 21h
      JC failed 
      MOV fd, AX 
      POP CX
      POP AX
      POP DX
      JMP cont
    }

failed:
    fprintf(stderr, "Create failed\n");
    exit(0);

cont:

 
  printf("Enter text, indicate EOF by Enter\n");

//  while( (c = getchar()) != EOF)
//     fputc(c, fp);
 

  asm {
         PUSH AX
         MOV AH,1
         INT 21h
         MOV c,0
         MOV BYTE PTR c,AL
         POP AX
     } // asm
 

  while (c != 13)
  {
   asm {
    PUSH AX
    PUSH BX
    PUSH CX
    PUSH DX
    MOV BX,fd
    MOV CX,1
    MOV DX,OFFSET c
    MOV AH,40h
    INT 21h

   POP DX
   POP CX
   POP BX
   POP AX

   } // asm

   asm {
         PUSH AX
         MOV AH,1
         INT 21h
         MOV c,0
         MOV BYTE PTR c,AL
         POP AX
     } // asm
  } // while

//  fclose(fp);

  asm{
     MOV BX,fd
     MOV AH,3Eh
     INT 21h
   } // asm

  return 0;

} // main
