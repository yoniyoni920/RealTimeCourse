// textf1.c

#include <stdio.h>


int main(int argc, char *argv[])
{
  FILE *fp;
  int c;
  char fname[20] = "t11.txt";

  fp = fopen(fname, "wt");
  if (fp == NULL)
   {
    perror("fopen");
    exit(0);
   } // if
  printf("Enter text, indicate EOF by Ctrl-Z\n");

  while( (c = getchar()) != EOF)
     fputc(c, fp);
 
  fclose(fp);

  return 0;

} // main
