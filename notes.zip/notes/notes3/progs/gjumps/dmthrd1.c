// dmthrd1.c

#include <stdio.h>
#include <dos.h>
#include <setjmp.h>

#define COUNTVALUE 1000000

void interrupt (*old8isr)(void);
static jmp_buf jmpbuf1;
static jmp_buf jmpbuf2;

unsigned long int count1;
unsigned long int count2;
int main_thread_active = 1;
int sec_thread_alive = 0;

void transfer_control_to_sec()
{
		if (setjmp(jmpbuf1) == 0)
		{
			main_thread_active = 0;
			longjmp(jmpbuf2, 1);
		} // if

} // transfer_control_ to sec()

void transfer_control_to_main()
{
		if (setjmp(jmpbuf2) == 0)
		{
			main_thread_active = 1;
			longjmp(jmpbuf1, 1);
		} // if

} // transfer_control_ to_main()

void main_final_code()
{
  while(sec_thread_alive == 1)
    transfer_control_to_sec();

} // main_final_code()

void main_thread_code()
{
   printf("Got to main\n");

   count1 = 0;
   while(count1 < COUNTVALUE)
   {
	count1++;
        if ((count1 % 100000) == 0)
		printf("count1 = %lu\n", count1);
   } // while

    main_final_code();

} //main_thread_code

void sec_thread_code()
{
   long int local_arr[512]; // alocate stack
   int i;

   printf("Got to sec\n");
   for(i=0; i < 512; i++) // make sure in use
       local_arr[i] = 17; 
  
   count2 = 0;

   while(count2 < COUNTVALUE)
   {
	count2++;
        if ((count2 % 100000) == 0)
		printf("count2 = %lu\n", count2);
   } // while
  
  sec_thread_alive = 0;

transfer_control_to_main();

} //sec_thread_code



void interrupt  new8isr(void)
{

  (*old8isr)();

 
  if (sec_thread_alive == 0)
    if (main_thread_active == 1)
	goto sof; // return by iret
    else
	longjmp(jmpbuf1, 1);
   else // sec_thread_alive == 1
	{
	 if (main_thread_active == 1)
	 {
          transfer_control_to_sec();
	 } //if
	else // main_thread_active == 0
	 {
           transfer_control_to_main();
	  } // else

	} // else


sof: 
} // new8isr

void create_and_run_sec_thread()
{
    if (setjmp(jmpbuf1) == 0)
	{
		sec_thread_alive = 1;
		main_thread_active = 0;
		sec_thread_code();
     } // if
   else
	return;

} // create_and_run_sec_thread()


int main()
{
    // just t be sure

   old8isr = getvect(8);
   setvect(8, new8isr);
   sec_thread_alive = 0;
   main_thread_active = 1;
   create_and_run_sec_thread();
   
   main_thread_code();
   printf("\nterminating ...\n");

   setvect(8, old8isr);

  return 0;
} // main