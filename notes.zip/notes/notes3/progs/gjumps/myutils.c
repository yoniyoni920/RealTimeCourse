/* myutils.c - service utility routines */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>


/*  print system error messge and  terminate */

/*  print application error messge and  terminate */
void fatal(msg)
char *msg;
{
 fprintf(stderr, "Application program error: %s.", msg);
 exit(2);
}
