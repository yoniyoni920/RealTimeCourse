/* myutils.h - include declarations of utilities */

#include <errno.h>
#include <errno.h>

extern void fatal();
extern void syserr();
