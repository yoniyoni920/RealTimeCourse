/* jmpdemo2.c - Program ^C to interrupt an activity, not the 
entire program.  */

#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <signal.h>
#include <setjmp.h>
#ifdef CYGWIN
#include <unistd.h>
#else
#include <dos.h>
#endif
#include "myutils.h"

static sigjmp_buf jmpbuf;

void syserr(char s[])
{
  perror(s);
  exit(1);
} // syserr

void ha_ha_loop()
{
   while(1)
     {
       puts("Ha  Ha  Ha ");
       sleep(3);
     } /* while */

} /* ha_ha_loop */

void dollar_loop()
{
   while(1)
    {
      puts("$$$$$$$$$ ");
      sleep(3);
    } /* while */

} /* dollar_loop */

void mainloop()
{
  char answer[80];
 
  while (1)
  {
    puts("Press 1 for Ha Ha Ha.");
    puts("Press 2 for $$$$$$$$.");
    puts("Press 3 for to quit.");

    fgets(answer, 80, stdin);

    switch (answer[0])
    {
      case '1':
       ha_ha_loop();
      case '2':
       dollar_loop();
      case '3':
       return;
    } /* switch */
  } /* while */

} /* mainloop */


static void jumper() /* abandon internal activity, resume mainloop */
{
  siglongjmp(jmpbuf,1);
  fatal("Longjmp returned");
}


int main()
{

  if (signal(SIGINT, jumper) == SIG_ERR)
      syserr("signal");
  if (sigsetjmp(jmpbuf,1) != 0)
    puts("....Interrupt");

 mainloop(); 

 return 0;

} /* main */

