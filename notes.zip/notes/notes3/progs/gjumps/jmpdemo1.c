/* jmpdemo1.c - Program a main menu to return to  */

#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#ifdef TURBOC
#include <dos.h>
#else
#include <unistd.h>
#endif
#include "defs.h"


static jmp_buf jmpbuf;

void ask_return()
{
  char str[80];
  
     puts("Return to main menu (y/n)?");
     fgets(str,80, stdin);

     if (str[0] == 'y')
         longjmp(jmpbuf,1);

} /* ask_return */

void ha_ha_loop()
{
 int i, c;

 while(1)
  {
     for(i=0; i < 3; i++)
     {
       puts("Ha Ha Ha");
       sleep(3);
     } /* for */
    ask_return(); 
  } /* while */

} /* ha_ha_loop */

void dollar_loop()
{

 int i;

   while(1)
    {
     for(i=0; i < 3; i++)
      {
        puts("$$$$$$$$$ ");
        sleep(3);
      } /* for */

      ask_return(); 
    } /* while */

} /* dollar_loop */



void mainloop()
{
  char answer[80];
 
  while (1)
  {
    puts("Press 1 for Ha Ha Ha.");
    puts("Press 2 for $$$$$$$$.");
    puts("Press 3 for to quit.");

    fgets(answer,80, stdin);

    switch (answer[0])
    {
      case '1':
       ha_ha_loop();
      case '2':
       dollar_loop();
      case '3':
       return;
    } /* switch */
  } /* while */

} /* mainloop */


int main()
{
  if (setjmp(jmpbuf) == 0)
   puts("Main Menu:");
  else
    puts("Returning to main menu....");
  

 mainloop(); 

 return 0;

} /* main */

