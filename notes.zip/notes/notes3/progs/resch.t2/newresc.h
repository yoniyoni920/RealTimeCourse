// newresc.h

extern int currpid_temp_prio;
