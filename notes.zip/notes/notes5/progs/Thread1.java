//  Thread1.java

class RunnableThread implements Runnable {

  Thread runner;
   public RunnableThread() 
   {
   } // RunnableThread()

   public RunnableThread(String threadName) 
   {
     runner = new Thread(this, threadName); // (1) Create a new thread.
     System.out.println(runner.getName() + ": ");
     runner.start(); // (2) Start the thread.
   } // RunnableThread
   public void run() 
    {
	//Display info about this particular thread
		System.out.print(Thread.currentThread() + " :" );
		System.out.println("Hello World!");
    } // run
} // RunnableThread


public class Thread1 {

  public static void main(String[] args) 
      {
	Thread thread1 = new Thread(new RunnableThread(), "thread1");
	Thread thread2 = new Thread(new RunnableThread(), "thread2");

        System.out.println("main: Before thread3");

	RunnableThread thread3 = new RunnableThread("thread3");
	//Start the threads

        System.out.println("main: Before starts");

	thread1.start();
	thread2.start();
	try {
		//delay for one second
		Thread.currentThread().sleep(1000);
	    } // try 
           catch (InterruptedException e) 
                {
		} // catch
		//Display info about the main thread    
		System.out.println("main: " + Thread.currentThread());
	} // main
}// Thread1.java
