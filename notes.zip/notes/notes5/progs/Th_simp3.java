// Th_simp3.java

class global_rec
{
  int n;
}// global_rec

class Pthread1 extends Thread 
{
   global_rec global_rec_ref;

  Pthread1(String threadName, global_rec global_rec_ref) 
  {
    super(threadName); // Initialize thread
    this.global_rec_ref = global_rec_ref;
  }//  Pthread1(String threadName)

 public void run() 
  {
   for(int i=0; i < 20; i++)
   {
     synchronized(global_rec_ref)
     {
       System.out.println(" n = " + global_rec_ref.n);
       try
       {
         global_rec_ref.notify();
         if ( i < 19)
            global_rec_ref.wait();
       } //
       catch(InterruptedException ie)
       {
       } // catch
     } // synchronized
   } // for
  } // run
} // Pthread1

class Pthread2 extends Thread 
{
   global_rec global_rec_ref;

  Pthread2(String threadName, global_rec global_rec_ref) 
  {
    super(threadName); // Initialize thread
    this.global_rec_ref = global_rec_ref;
  }//  Pthread2(String threadName)

 public void run()
  {
   for(int i=0; i < 20; i++)
   {

     synchronized(global_rec_ref)
     {
       global_rec_ref.n++;
       try
       {
         global_rec_ref.notify();
         if ( i < 19)
            global_rec_ref.wait();
       } //
       catch(InterruptedException ie)
       {
       } // catch
     } //  synchronized

   } // for
  } // run
} // Pthread2

public class Th_simp3 
{

  public static void main(String[] args) throws InterruptedException  
   {
      global_rec grec = new global_rec();
      grec.n = 0;

      Pthread1 pthread1 = new Pthread1("printer", grec);
      Pthread2 pthread2 = new Pthread2("incrementer", grec);
   
     pthread1.start();
     pthread2.start();
     pthread1.join();
     pthread2.join();

     System.out.println("Application ends.");

   } // main
} //  Th_simp3.java

