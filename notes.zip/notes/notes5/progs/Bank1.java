// Bank1.java

class global_rec
{
  int arr[];
}// global_rec

class Pthread1 extends Thread 
{
   global_rec global_rec_ref;

  Pthread1(String threadName, global_rec global_rec_ref) 
  {
    super(threadName); // Initialize thread
    this.global_rec_ref = global_rec_ref;
  }//  Pthread1(String threadName)

 public void run() 
  {
   int i;
   int sum;
   i = 0;
   while(true)
   {
    sum = global_rec_ref.arr[0] + global_rec_ref.arr[1];
    if ( sum != 650 || (i % 100000 == 0))
       System.out.println("sum = " + sum);
    i++;
   } //while
  } // run
} // Pthread1

class Pthread2 extends Thread 
{
   global_rec global_rec_ref;

  Pthread2(String threadName, global_rec global_rec_ref) 
  {
    super(threadName); // Initialize thread
    this.global_rec_ref = global_rec_ref;
  }//  Pthread2(String threadName)

 public void run()
  {
   int i;
   int sums[] = new int[3];
   int sum;
   sums[0] = 100;
   sums[1] = -125;
   sums[2] = 25;
   i = 0;
   while(true)
   {
    sum = sums[i % 3];
    global_rec_ref.arr[0] += sum;
    global_rec_ref.arr[1] -= sum;
    i++;
   } //while
  } // run
} // Pthread2

public class Bank1 
{

  public static void main(String[] args) throws InterruptedException  
   {
      global_rec grec = new global_rec();
      grec.arr =  new int [2];
      grec.arr[0] = 400;
      grec.arr[1] = 250;

      Pthread1 pthread1 = new Pthread1("printer", grec);
      Pthread2 pthread2 = new Pthread2("transferrer", grec);
   
     pthread1.start();
     pthread2.start();
     pthread1.join();
     pthread2.join();

     System.out.println("Application ends.");

   } // main
} //  Bank1.java

