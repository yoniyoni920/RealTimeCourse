// game.java

import java.util.Scanner;

class position
{
  public int x;
  public int y;

} // position

class GlobalRec
{
  public final int target_number = 4;
  public final int arrow_number = 5;
  public final int target_disp = 20;
  public final int char_arr_size = 1024;


  public int point_in_cycle;
  public int gcycle_length;
  public int gno_of_pids;
  public String displayString;
  public position [] target_pos;
  public position [] arrow_pos;
  public int gun_position;
  public int no_of_arrows;
  public char ch_arr[];
  public int ch_arr_front;
  public int ch_arr_rear;

   GlobalRec()
   {
    int i;
    target_pos = new position[target_number];
    arrow_pos = new position[arrow_number];
    ch_arr = new char [char_arr_size];
    ch_arr_front = -1;
    ch_arr_rear = -1;

    for(i=0; i < target_number; i++)
       target_pos[i] = new position();   

    for(i=0; i < arrow_number; i++)
      arrow_pos[i] = new position();   
    displayString = new String("");
   }//

} // GlobalRec


class Displayer extends Thread
{
  GlobalRec grec;

  Displayer(GlobalRec grec)
  {
   this.grec = grec;
  } // Displayer

  public void run()
  {
    synchronized(grec)
    {
     while(true)
     {
     try {
      grec.wait();
     } catch(InterruptedException ie)
       {
        System.out.println("Exception: " + ie.getMessage());
       } // catch
      System.out.println();
      System.out.print(grec.displayString);
     } // while

    } // synchronized(grec)   

  } // run

} // Displayer

class Receiver extends Thread
{
  GlobalRec grec;

  Receiver(GlobalRec grec)
  {
   this.grec = grec;
  } // Updater

  public void run()
  {
    int i;
    String str;
    Scanner input = new Scanner(System.in);
    char ch;

    while(true)
    {
       str = input.nextLine();
       str = str.trim();


      synchronized(grec)
      {

       for(i =0; i < str.length(); i++)
       {
          ch = str.charAt(i);
 
          grec.ch_arr_rear++;
          grec.ch_arr[grec.ch_arr_rear] = ch;
          if (grec.ch_arr_front == -1)
              grec.ch_arr_front = 0;
       } // for   
      } // synchronized(grec)

    } // while

  } // run
  
} // Receiver


class Updater extends Thread
{
  GlobalRec grec;

  Updater(GlobalRec grec)
  {
   this.grec = grec;
  } // Updater

  public void run()
  {
    char [][] displayDraft;
    final int rows = 25;
    final int cols = 80;

    displayDraft = new char[rows][cols];

    while(true)
    {
     int i, j;


      synchronized(grec)
      {
     //  try {
     //   grec.wait();
     //  } catch(InterruptedException ie)
     //  {
     //   System.out.println("Exception: " + ie.getMessage());
     //  } // catch

       grec.target_pos[0].x = 3;
       grec.target_pos[0].y = 0;

       for(i=1; i < grec.target_number; i++)
        {
          grec.target_pos[i].x = i*grec.target_disp;
          grec.target_pos[i].y = 0;

        } // for
       grec.gun_position = 39;

       for(i=0; i < grec.arrow_number; i++)
        {
          grec.arrow_pos[i].x = -1;
          grec.arrow_pos[i].y = -1;
        } // for


        while(true)
        {
          char ch;
          try {
           grec.wait();
          } catch(InterruptedException ie)
            {
             System.out.println("Exception: " + ie.getMessage());
            } // catch
           
           while(grec.ch_arr_front != -1)
           {
             ch = grec.ch_arr[grec.ch_arr_front];
             if(grec.ch_arr_front != grec.ch_arr_rear)
               grec.ch_arr_front++;
             else 
                grec.ch_arr_front = grec.ch_arr_rear = -1;

             if ((ch == 'a') || (ch == 'A'))
               if (grec.gun_position >= 2)
                  grec.gun_position--;
               else;
             else if ((ch == 'd') || (ch == 'D'))
                    if (grec.gun_position <= 77)
                       grec.gun_position++;
                    else;
                else if ( ((ch == 'w') || (ch == 'W')) &&
                      grec.no_of_arrows < grec.arrow_number)    
                     {
                       grec.arrow_pos[grec.no_of_arrows].x = grec.gun_position;
                       grec.arrow_pos[grec.no_of_arrows].y = 23;
                       grec.no_of_arrows++;
                     } // if
                     else;
           } // while(grec.front != -1) 

          for(i=0; i < rows; i++)
             for(j=0; j < cols; j++)
                displayDraft[i][j] = ' ';


           displayDraft[22][grec.gun_position] = '^';
           displayDraft[23][grec.gun_position-1] = '/';
           displayDraft[23][grec.gun_position] = '|';
           displayDraft[23][grec.gun_position+1] = '\\';
           displayDraft[24][grec.gun_position] = '|';

           for(i=0; i < grec.arrow_number; i++)
             if (grec.arrow_pos[i].x != -1)
             {
               if (grec.arrow_pos[i].y > 1)
                    grec.arrow_pos[i].y--;
               displayDraft[grec.arrow_pos[i].y][grec.arrow_pos[i].x]
                                                                   = '^';
               displayDraft[grec.arrow_pos[i].y+1][grec.arrow_pos[i].x]
                                                                  = '|';
             } // if

           for(i=0; i < grec.target_number; i++)
              if (grec.target_pos[i].x != -1)
              {
               if (grec.target_pos[i].y < 22)
                        grec.target_pos[i].y++;
               displayDraft[grec.target_pos[i].y][grec.target_pos[i].x]
                                                                     = '*';
              } // if

           grec.displayString = "";
           for(i=0; i < rows; i++)
              for(j=0; j < cols; j++)
                  grec.displayString += displayDraft[i][j];


        } // while

      } // synchronized(grec)
    } // while

  } // run

} // Updater

class Scheduler extends Thread
{
  GlobalRec grec;

  Scheduler(GlobalRec grec)
  {
   this.grec = grec;
  } // Updater
  
 public void run()
 {

 while(true)
 {
   synchronized(grec)
    {
     grec.notify();
    }// synchronized(grec)

    try
    {   
     Thread.currentThread().sleep(1000);
    } // try
    catch (InterruptedException e)
    {
     System.out.println("Exception: " + e.getMessage());
    } // catch 
  } // while
 } // run 

} // Scheduler

public class game 
{
    public static void main(String[] args) throws InterruptedException 
    {
     GlobalRec grec = new GlobalRec();

     Scheduler sch = new Scheduler(grec);
     Updater upd = new Updater(grec);
     Receiver rcv = new Receiver(grec);
     Displayer disp = new Displayer(grec);
     rcv.setPriority(Thread.MAX_PRIORITY);
     sch.setPriority(Thread.MAX_PRIORITY);

     upd.start();     
     disp.start();
     rcv.start();
     sch.start();

    
     
    }// main
} // game
